# searchAPI

This is a simple search API that works well with ARXIV.
